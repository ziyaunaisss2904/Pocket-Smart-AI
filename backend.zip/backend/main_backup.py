import os
import json
import re
import base64
import shutil
import urllib.parse
from datetime import datetime, timedelta
from io import BytesIO
import asyncio
from typing import List, Optional, Dict, Any, Union
import uuid

from fastapi import (
    FastAPI,
    HTTPException,
    Depends,
    File,
    UploadFile,
    Form,
    Request,
    status,
    Cookie
)

from fastapi.responses import JSONResponse, RedirectResponse

from fastapi.middleware.cors import CORSMiddleware

from fastapi.security import (
    OAuth2PasswordBearer,
    OAuth2PasswordRequestForm
)

from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from pydantic import BaseModel, EmailStr
from passlib.context import CryptContext
from jose import JWTError, jwt
from PIL import Image

import google.generativeai as genai

from dotenv import load_dotenv


# Load environment variables
load_dotenv()


# FastAPI initialization
app = FastAPI(
    title="PocketSmart: AI Budget Planner"
)


# Configuration
SECRET_KEY = os.getenv(
    "SECRET_KEY",
    "your_secret_key"
)

ALGORITHM = "HS256"

ACCESS_TOKEN_EXPIRE_MINUTES = 30


# ============================================================
# EPIC 2 - CORE FUNCTIONALITIES
# ============================================================

# Request model
class RecommendationRequest(BaseModel):
    situation: str
    budget: Optional[float] = None
    preferences: Optional[str] = None


# ============================================================
# PRODUCT LINKS
# ============================================================

def get_product_links(category: str) -> Dict[str, str]:

    encoded_category = urllib.parse.quote_plus(category)

    return {
        "Amazon": f"https://www.amazon.in/s?k={encoded_category}",
        "Flipkart": f"https://www.flipkart.com/search?q={encoded_category}",
        "IKEA": f"https://www.ikea.com/in/en/search/?q={encoded_category}"
    }


# ============================================================
# HOME RECOMMENDATIONS
# ============================================================

def get_home_recommendations(
    situation: str,
    budget: Optional[float] = None,
    preferences: Optional[str] = None
) -> List[Dict[str, Any]]:

    situation_lower = situation.lower()

    recommendations = []

    if "living room" in situation_lower:

        recommendations = [
            {
                "category": "Sofa",
                "description": "Comfortable modern sofa"
            },
            {
                "category": "Coffee Table",
                "description": "Modern coffee table"
            },
            {
                "category": "Floor Lamp",
                "description": "Warm living room lighting"
            },
            {
                "category": "Wall Decor",
                "description": "Minimal wall decoration"
            }
        ]

    elif "bedroom" in situation_lower:

        recommendations = [
            {
                "category": "Bed",
                "description": "Comfortable modern bed"
            },
            {
                "category": "Bedside Table",
                "description": "Compact bedside table"
            },
            {
                "category": "Table Lamp",
                "description": "Soft bedroom lighting"
            },
            {
                "category": "Curtains",
                "description": "Simple bedroom curtains"
            }
        ]

    elif "kitchen" in situation_lower:

        recommendations = [
            {
                "category": "Kitchen Storage",
                "description": "Kitchen storage solution"
            },
            {
                "category": "Kitchen Lighting",
                "description": "Bright kitchen lighting"
            },
            {
                "category": "Dining Table",
                "description": "Compact dining table"
            }
        ]

    else:

        recommendations = [
            {
                "category": "Furniture",
                "description": "Modern furniture"
            },
            {
                "category": "Decor",
                "description": "Simple decoration"
            },
            {
                "category": "Lighting",
                "description": "Suitable lighting"
            }
        ]

    # Add shopping links
    for item in recommendations:
        item["product_links"] = get_product_links(
            item["category"]
        )

    return recommendations


# ============================================================
# /generate-home ROUTE
# ============================================================

@app.post("/generate-home")
async def generate_home(
    request: RecommendationRequest
):

    recommendations = get_home_recommendations(
        situation=request.situation,
        budget=request.budget,
        preferences=request.preferences
    )

    return {
        "success": True,
        "type": "home",
        "situation": request.situation,
        "budget": request.budget,
        "preferences": request.preferences,
        "recommendations": recommendations
    }


# ============================================================
# PARTY RECOMMENDATIONS
# ============================================================

def get_party_recommendations(
    situation: str,
    budget: Optional[float] = None,
    preferences: Optional[str] = None
) -> List[Dict[str, Any]]:

    situation_lower = situation.lower()

    recommendations = []

    if "birthday" in situation_lower:

        recommendations = [
            {
                "category": "Catering",
                "description": "Birthday catering options"
            },
            {
                "category": "Venue",
                "description": "Birthday party venue"
            },
            {
                "category": "Decoration",
                "description": "Birthday decorations"
            }
        ]

    elif "wedding" in situation_lower:

        recommendations = [
            {
                "category": "Catering",
                "description": "Wedding catering options"
            },
            {
                "category": "Venue",
                "description": "Wedding venue options"
            },
            {
                "category": "Decoration",
                "description": "Wedding decoration options"
            }
        ]

    elif "baby shower" in situation_lower:

        recommendations = [
            {
                "category": "Catering",
                "description": "Baby shower catering"
            },
            {
                "category": "Venue",
                "description": "Baby shower venue"
            },
            {
                "category": "Decoration",
                "description": "Baby shower decorations"
            }
        ]

    else:

        recommendations = [
            {
                "category": "Catering",
                "description": "General event catering"
            },
            {
                "category": "Venue",
                "description": "Suitable event venue"
            },
            {
                "category": "Decoration",
                "description": "Event decoration options"
            }
        ]

    # Add shopping links
    for item in recommendations:
        item["product_links"] = get_product_links(
            item["category"]
        )

    return recommendations


# ============================================================
# /generate-party ROUTE
# ============================================================

@app.post("/generate-party")
async def generate_party(
    request: RecommendationRequest
):

    recommendations = get_party_recommendations(
        situation=request.situation,
        budget=request.budget,
        preferences=request.preferences
    )

    return {
        "success": True,
        "type": "party",
        "situation": request.situation,
        "budget": request.budget,
        "preferences": request.preferences,
        "recommendations": recommendations
    }
