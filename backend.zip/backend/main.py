import os
import json
import re
import base64
import shutil
import urllib.parse
import hashlib
import hmac
import secrets

from datetime import datetime, timedelta
from io import BytesIO
import asyncio
from typing import List, Optional, Dict, Any, Union
import uuid

from fastapi import (
    FastAPI,
    HTTPException,
    Depends,
    File,
    UploadFile,
    Form,
    Request,
    status,
    Cookie
)

from fastapi.responses import JSONResponse, RedirectResponse

from fastapi.middleware.cors import CORSMiddleware

from fastapi.security import (
    OAuth2PasswordBearer,
    OAuth2PasswordRequestForm
)

from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from pydantic import BaseModel, EmailStr
from passlib.context import CryptContext
from jose import JWTError, jwt
from PIL import Image

import google.generativeai as genai

from dotenv import load_dotenv


# ============================================================
# LOAD ENVIRONMENT VARIABLES
# ============================================================

load_dotenv()


# ============================================================
# FASTAPI INITIALIZATION
# ============================================================

app = FastAPI(
    title="PocketSmart: AI Budget Planner"
)


# ============================================================
# CONFIGURATION
# ============================================================

SECRET_KEY = os.getenv(
    "SECRET_KEY",
    "your_secret_key"
)

ALGORITHM = "HS256"

ACCESS_TOKEN_EXPIRE_MINUTES = 30


# ============================================================
# EPIC 2 - CORE FUNCTIONALITIES
# ============================================================


# ============================================================
# REQUEST MODEL
# ============================================================

class RecommendationRequest(BaseModel):
    situation: str
    budget: Optional[float] = None
    preferences: Optional[str] = None


# ============================================================
# PRODUCT LINKS
# ============================================================

def get_product_links(category: str) -> Dict[str, str]:
    """
    Creates search links for the recommended category.
    """

    encoded_category = urllib.parse.quote_plus(category)

    return {
        "Amazon": f"https://www.amazon.in/s?k={encoded_category}",
        "Flipkart": f"https://www.flipkart.com/search?q={encoded_category}",
        "IKEA": f"https://www.ikea.com/in/en/search/?q={encoded_category}"
    }


# ============================================================
# HOME RECOMMENDATIONS
# ============================================================

def get_home_recommendations(
    situation: str,
    budget: Optional[float] = None,
    preferences: Optional[str] = None
) -> List[Dict[str, Any]]:
    """
    Generates home interior recommendations based on
    the user's situation.

    Categories:
    - Furniture
    - Decor
    - Lighting
    """

    situation_lower = situation.lower()

    recommendations = []

    # --------------------------------------------------------
    # LIVING ROOM
    # --------------------------------------------------------

    if "living room" in situation_lower:

        recommendations = [
            {
                "category": "Sofa",
                "type": "Furniture",
                "description": "Comfortable modern sofa"
            },
            {
                "category": "Coffee Table",
                "type": "Furniture",
                "description": "Modern coffee table"
            },
            {
                "category": "Floor Lamp",
                "type": "Lighting",
                "description": "Warm living room lighting"
            },
            {
                "category": "Wall Decor",
                "type": "Decor",
                "description": "Minimal wall decoration"
            }
        ]

    # --------------------------------------------------------
    # BEDROOM
    # --------------------------------------------------------

    elif "bedroom" in situation_lower:

        recommendations = [
            {
                "category": "Bed",
                "type": "Furniture",
                "description": "Comfortable modern bed"
            },
            {
                "category": "Bedside Table",
                "type": "Furniture",
                "description": "Compact bedside table"
            },
            {
                "category": "Table Lamp",
                "type": "Lighting",
                "description": "Soft bedroom lighting"
            },
            {
                "category": "Curtains",
                "type": "Decor",
                "description": "Simple bedroom curtains"
            }
        ]

    # --------------------------------------------------------
    # KITCHEN
    # --------------------------------------------------------

    elif "kitchen" in situation_lower:

        recommendations = [
            {
                "category": "Kitchen Storage",
                "type": "Furniture",
                "description": "Kitchen storage solution"
            },
            {
                "category": "Kitchen Lighting",
                "type": "Lighting",
                "description": "Bright kitchen lighting"
            },
            {
                "category": "Dining Table",
                "type": "Furniture",
                "description": "Compact dining table"
            }
        ]

    # --------------------------------------------------------
    # STUDY ROOM
    # --------------------------------------------------------

    elif "study" in situation_lower or "office" in situation_lower:

        recommendations = [
            {
                "category": "Study Table",
                "type": "Furniture",
                "description": "Comfortable study table"
            },
            {
                "category": "Office Chair",
                "type": "Furniture",
                "description": "Ergonomic chair"
            },
            {
                "category": "Desk Lamp",
                "type": "Lighting",
                "description": "Focused study lighting"
            },
            {
                "category": "Bookshelf",
                "type": "Furniture",
                "description": "Space-saving bookshelf"
            }
        ]

    # --------------------------------------------------------
    # GENERAL HOME
    # --------------------------------------------------------

    else:

        recommendations = [
            {
                "category": "Furniture",
                "type": "Furniture",
                "description": "Modern furniture"
            },
            {
                "category": "Decor",
                "type": "Decor",
                "description": "Simple decoration"
            },
            {
                "category": "Lighting",
                "type": "Lighting",
                "description": "Suitable lighting"
            }
        ]

    # --------------------------------------------------------
    # ADD PRODUCT LINKS
    # --------------------------------------------------------

    for item in recommendations:

        item["product_links"] = get_product_links(
            item["category"]
        )

    return recommendations


# ============================================================
# /generate-home ROUTE
# ============================================================

@app.post("/generate-home")
async def generate_home(
    request: RecommendationRequest
):

    recommendations = get_home_recommendations(
        situation=request.situation,
        budget=request.budget,
        preferences=request.preferences
    )

    return {
        "success": True,
        "type": "home",
        "situation": request.situation,
        "budget": request.budget,
        "preferences": request.preferences,
        "recommendations": recommendations
    }


# ============================================================
# PARTY RECOMMENDATIONS
# ============================================================

def get_party_recommendations(
    situation: str,
    budget: Optional[float] = None,
    preferences: Optional[str] = None
) -> List[Dict[str, Any]]:
    """
    Generates party/event recommendations.

    Categories:
    - Catering
    - Venue
    - Decoration
    """

    situation_lower = situation.lower()

    recommendations = []

    # --------------------------------------------------------
    # BIRTHDAY
    # --------------------------------------------------------

    if "birthday" in situation_lower:

        recommendations = [
            {
                "category": "Birthday Catering",
                "type": "Catering",
                "description": "Birthday catering options"
            },
            {
                "category": "Birthday Venue",
                "type": "Venue",
                "description": "Birthday party venue"
            },
            {
                "category": "Birthday Decoration",
                "type": "Decoration",
                "description": "Birthday decorations"
            }
        ]

    # --------------------------------------------------------
    # WEDDING
    # --------------------------------------------------------

    elif "wedding" in situation_lower:

        recommendations = [
            {
                "category": "Wedding Catering",
                "type": "Catering",
                "description": "Wedding catering options"
            },
            {
                "category": "Wedding Venue",
                "type": "Venue",
                "description": "Wedding venue options"
            },
            {
                "category": "Wedding Decoration",
                "type": "Decoration",
                "description": "Wedding decoration options"
            }
        ]

    # --------------------------------------------------------
    # BABY SHOWER
    # --------------------------------------------------------

    elif "baby shower" in situation_lower:

        recommendations = [
            {
                "category": "Baby Shower Catering",
                "type": "Catering",
                "description": "Baby shower catering"
            },
            {
                "category": "Baby Shower Venue",
                "type": "Venue",
                "description": "Baby shower venue"
            },
            {
                "category": "Baby Shower Decoration",
                "type": "Decoration",
                "description": "Baby shower decorations"
            }
        ]

    # --------------------------------------------------------
    # PARTY
    # --------------------------------------------------------

    elif "party" in situation_lower:

        recommendations = [
            {
                "category": "Party Catering",
                "type": "Catering",
                "description": "General party catering"
            },
            {
                "category": "Party Venue",
                "type": "Venue",
                "description": "Suitable party venue"
            },
            {
                "category": "Party Decoration",
                "type": "Decoration",
                "description": "Party decoration options"
            }
        ]

    # --------------------------------------------------------
    # GENERAL EVENT
    # --------------------------------------------------------

    else:

        recommendations = [
            {
                "category": "Event Catering",
                "type": "Catering",
                "description": "General event catering"
            },
            {
                "category": "Event Venue",
                "type": "Venue",
                "description": "Suitable event venue"
            },
            {
                "category": "Event Decoration",
                "type": "Decoration",
                "description": "Event decoration options"
            }
        ]

    # --------------------------------------------------------
    # ADD PRODUCT LINKS
    # --------------------------------------------------------

    for item in recommendations:

        item["product_links"] = get_product_links(
            item["category"]
        )

    return recommendations


# ============================================================
# /generate-party ROUTE
# ============================================================

@app.post("/generate-party")
async def generate_party(
    request: RecommendationRequest
):

    recommendations = get_party_recommendations(
        situation=request.situation,
        budget=request.budget,
        preferences=request.preferences
    )

    return {
        "success": True,
        "type": "party",
        "situation": request.situation,
        "budget": request.budget,
        "preferences": request.preferences,
        "recommendations": recommendations
    }


# ============================================================
# JEWELRY RECOMMENDATIONS
# ============================================================

def get_jewelry_recommendations(
    situation: str,
    image_style: str = "general"
) -> List[Dict[str, Any]]:
    """
    Generates jewelry recommendations based on text
    and detected/general image style.
    """

    situation_lower = situation.lower()

    recommendations = []

    # --------------------------------------------------------
    # WEDDING / BRIDAL
    # --------------------------------------------------------

    if (
        "wedding" in situation_lower
        or "bridal" in situation_lower
    ):

        recommendations = [
            {
                "category": "Gold Necklace",
                "style": "Traditional",
                "description": "Traditional gold necklace suitable for wedding occasions"
            },
            {
                "category": "Jhumka Earrings",
                "style": "Traditional",
                "description": "Traditional jhumka earrings"
            },
            {
                "category": "Bangles",
                "style": "Traditional",
                "description": "Traditional bangles for wedding styling"
            }
        ]

    # --------------------------------------------------------
    # PARTY
    # --------------------------------------------------------

    elif "party" in situation_lower:

        recommendations = [
            {
                "category": "Statement Necklace",
                "style": "Modern",
                "description": "Elegant statement necklace for parties"
            },
            {
                "category": "Drop Earrings",
                "style": "Modern",
                "description": "Stylish drop earrings"
            },
            {
                "category": "Bracelet",
                "style": "Modern",
                "description": "Simple modern bracelet"
            }
        ]

    # --------------------------------------------------------
    # CASUAL
    # --------------------------------------------------------

    elif "casual" in situation_lower:

        recommendations = [
            {
                "category": "Stud Earrings",
                "style": "Minimal",
                "description": "Simple everyday stud earrings"
            },
            {
                "category": "Simple Necklace",
                "style": "Minimal",
                "description": "Minimal necklace for everyday use"
            },
            {
                "category": "Simple Bracelet",
                "style": "Minimal",
                "description": "Simple everyday bracelet"
            }
        ]

    # --------------------------------------------------------
    # TRADITIONAL
    # --------------------------------------------------------

    elif "traditional" in situation_lower:

        recommendations = [
            {
                "category": "Temple Jewelry",
                "style": "Traditional",
                "description": "Traditional temple jewelry"
            },
            {
                "category": "Jhumka Earrings",
                "style": "Traditional",
                "description": "Classic traditional jhumka earrings"
            },
            {
                "category": "Gold Bangles",
                "style": "Traditional",
                "description": "Traditional gold bangles"
            }
        ]

    # --------------------------------------------------------
    # GENERAL
    # --------------------------------------------------------

    else:

        recommendations = [
            {
                "category": "Necklace",
                "style": image_style,
                "description": "Style-matched necklace"
            },
            {
                "category": "Earrings",
                "style": image_style,
                "description": "Style-matched earrings"
            },
            {
                "category": "Bracelet",
                "style": image_style,
                "description": "Style-matched bracelet"
            }
        ]

    # --------------------------------------------------------
    # ADD SHOPPING LINKS
    # --------------------------------------------------------

    for item in recommendations:

        item["product_links"] = get_product_links(
            item["category"]
        )

    return recommendations


# ============================================================
# /generate-jewelry ROUTE
# ============================================================

@app.post("/generate-jewelry")
async def generate_jewelry(
    situation: str = Form(...),
    image: Optional[UploadFile] = File(None)
):
    """
    Accepts text + optional image input and returns
    style-matched jewelry recommendations.
    """

    image_style = "general"

    # --------------------------------------------------------
    # PROCESS IMAGE
    # --------------------------------------------------------

    if image is not None:

        allowed_types = [
            "image/jpeg",
            "image/png",
            "image/jpg",
            "image/webp"
        ]

        if image.content_type not in allowed_types:

            raise HTTPException(
                status_code=400,
                detail="Please upload a JPG, JPEG, PNG, or WEBP image."
            )

        try:

            image_data = await image.read()

            pil_image = Image.open(
                BytesIO(image_data)
            )

            # Make sure the image can be read
            pil_image.verify()

            # Basic image-based category
            image_style = "image-matched"

        except Exception:

            raise HTTPException(
                status_code=400,
                detail="The uploaded file is not a valid image."
            )

    # --------------------------------------------------------
    # GET JEWELRY RECOMMENDATIONS
    # --------------------------------------------------------

    recommendations = get_jewelry_recommendations(
        situation=situation,
        image_style=image_style
    )

    return {
        "success": True,
        "type": "jewelry",
        "situation": situation,
        "image_received": image is not None,
        "image_style": image_style,
        "recommendations": recommendations
    }


# ============================================================
# BASIC HOME ROUTE
# ============================================================

@app.get("/")
async def root():

    return {
        "message": "PocketSmart AI Backend is running",
        "available_routes": [
            "/generate-home",
            "/generate-party",
            "/generate-jewelry"
        ]
    }
# ============================================================
# LOGIN / REGISTER / LOGOUT
# ============================================================

USERS_FILE = "users.json"


# ------------------------------------------------------------
# REGISTER REQUEST MODEL
# ------------------------------------------------------------

class RegisterRequest(BaseModel):
    username: str
    email: EmailStr
    password: str


# ------------------------------------------------------------
# LOGIN REQUEST MODEL
# ------------------------------------------------------------

class LoginRequest(BaseModel):
    username: str
    password: str


# ------------------------------------------------------------
# PASSWORD HASHING
# ------------------------------------------------------------

def hash_password(password: str) -> str:

    salt = secrets.token_bytes(16)

    password_hash = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt,
        100_000
    )

    return salt.hex() + ":" + password_hash.hex()


def verify_password(
    password: str,
    stored_password: str
) -> bool:

    try:

        salt_hex, hash_hex = stored_password.split(":")

        salt = bytes.fromhex(salt_hex)

        expected_hash = bytes.fromhex(hash_hex)

        actual_hash = hashlib.pbkdf2_hmac(
            "sha256",
            password.encode("utf-8"),
            salt,
            100_000
        )

        return hmac.compare_digest(
            actual_hash,
            expected_hash
        )

    except Exception:

        return False


# ------------------------------------------------------------
# LOAD USERS
# ------------------------------------------------------------

def load_users() -> Dict[str, Any]:

    if not os.path.exists(USERS_FILE):
        return {}

    try:

        with open(
            USERS_FILE,
            "r",
            encoding="utf-8"
        ) as file:

            return json.load(file)

    except (json.JSONDecodeError, OSError):

        return {}


# ------------------------------------------------------------
# SAVE USERS
# ------------------------------------------------------------

def save_users(
    users: Dict[str, Any]
) -> None:

    with open(
        USERS_FILE,
        "w",
        encoding="utf-8"
    ) as file:

        json.dump(
            users,
            file,
            indent=4
        )


# ------------------------------------------------------------
# CREATE SESSION TOKEN
# ------------------------------------------------------------

def create_session_token(
    username: str
) -> str:

    expire = datetime.utcnow() + timedelta(
        minutes=ACCESS_TOKEN_EXPIRE_MINUTES
    )

    payload = {
        "sub": username,
        "exp": expire
    }

    token = jwt.encode(
        payload,
        SECRET_KEY,
        algorithm=ALGORITHM
    )

    return token


# ------------------------------------------------------------
# REGISTER ROUTE
# ------------------------------------------------------------

@app.post("/register")
async def register(
    request: RegisterRequest
):

    username = request.username.strip()

    email = str(
        request.email
    ).strip().lower()

    password = request.password

    if not username:

        raise HTTPException(
            status_code=400,
            detail="Username is required."
        )

    if len(password) < 6:

        raise HTTPException(
            status_code=400,
            detail="Password must contain at least 6 characters."
        )

    users = load_users()

    if username in users:

        raise HTTPException(
            status_code=400,
            detail="Username already exists."
        )

    for existing_user in users.values():

        if existing_user.get("email") == email:

            raise HTTPException(
                status_code=400,
                detail="Email already registered."
            )

    users[username] = {

        "username": username,

        "email": email,

        "password": hash_password(password)
    }

    save_users(users)

    return {

        "success": True,

        "message": "Registration successful.",

        "username": username,

        "email": email
    }


# ------------------------------------------------------------
# LOGIN ROUTE
# ------------------------------------------------------------

@app.post("/login")
async def login(
    request: LoginRequest
):

    username = request.username.strip()

    password = request.password

    users = load_users()

    user = users.get(username)

    if user is None:

        raise HTTPException(
            status_code=401,
            detail="Invalid username or password."
        )

    if not verify_password(
        password,
        user["password"]
    ):

        raise HTTPException(
            status_code=401,
            detail="Invalid username or password."
        )

    token = create_session_token(username)

    response = JSONResponse(

        content={

            "success": True,

            "message": "Login successful.",

            "username": username
        }
    )

    response.set_cookie(

        key="access_token",

        value=token,

        httponly=True,

        max_age=ACCESS_TOKEN_EXPIRE_MINUTES * 60,

        samesite="lax"
    )

    return response


# ------------------------------------------------------------
# LOGOUT ROUTE
# ------------------------------------------------------------

@app.get("/logout")
async def logout():

    response = RedirectResponse(
        url="/login",
        status_code=303
    )

    response.delete_cookie(
        key="access_token"
    )

    return response


# ------------------------------------------------------------
# LOGIN PAGE ROUTE
# ------------------------------------------------------------

@app.get("/login")
async def login_page():

    return {

        "page": "login",

        "message": "Login page"
    }


# ------------------------------------------------------------
# REGISTER PAGE ROUTE
# ------------------------------------------------------------

@app.get("/register")
async def register_page():

    return {

        "page": "register",

        "message": "Register page"
    }