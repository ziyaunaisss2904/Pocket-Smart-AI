from fastapi import FastAPI

from backend.routes.auth_routes import router as auth_router
from backend.routes.planner_routes import router as planner_router
from backend.routes.session_routes import router as session_router
from backend.routes.recommendation_routes import (
    router as recommendation_router
)


app = FastAPI(
    title="Pocket Smarrt AI",
    description="Pocket Smarrt AI Backend API",
    version="1.0.0"
)


# ==========================================
# ROOT
# ==========================================

@app.get("/")
def home():

    return {
        "message": "Pocket Smarrt AI Backend is running",
        "status": "success"
    }


# ==========================================
# AUTHENTICATION ROUTES
# ==========================================

app.include_router(auth_router)


# ==========================================
# PLANNER ROUTES
# ==========================================

app.include_router(planner_router)


# ==========================================
# SESSION ROUTES
# ==========================================

app.include_router(session_router)


# ==========================================
# RECOMMENDATION ROUTES
# ==========================================

app.include_router(recommendation_router)