users = {}

sessions = {}

# ==========================================
# RECOMMENDATION HISTORY
# ==========================================

recommendation_history = {}