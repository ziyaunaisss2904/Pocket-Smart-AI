from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

from backend.auth import decode_access_token
from backend.session_store import (
    users,
    sessions,
    recommendation_history
)


router = APIRouter()

security = HTTPBearer()


# ==========================================
# GET CURRENT USER
# ==========================================

def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security)
):

    token = credentials.credentials

    payload = decode_access_token(token)

    if not payload:
        raise HTTPException(
            status_code=401,
            detail="Invalid or expired token"
        )

    username = payload.get("sub")

    if username not in users:
        raise HTTPException(
            status_code=401,
            detail="User not found"
        )

    return username


# ==========================================
# SESSION INFO
# ==========================================

@router.get("/session-info")
def session_info(
    username: str = Depends(get_current_user)
):

    user = users[username]

    return {
        "username": user["username"],
        "email": user["email"],
        "logged_in": sessions.get(
            username,
            {}
        ).get("logged_in", False)
    }


# ==========================================
# SESSION DATA
# ==========================================

@router.get("/session-data")
def session_data(
    username: str = Depends(get_current_user)
):

    return {
        "username": username,
        "message": "User session data retrieved successfully",
        "planner_data": []
    }
# ==========================================
# RECOMMENDATION HISTORY
# ==========================================

@router.get("/history")
def get_history(
    username: str = Depends(get_current_user)
):

    history = recommendation_history.get(
        username,
        []
    )

    return {
        "username": username,
        "history": history
    }