from fastapi import APIRouter, HTTPException

from backend.models import RegisterRequest, LoginRequest
from backend.auth import (
    hash_password,
    verify_password,
    create_access_token
)
from backend.session_store import users, sessions


router = APIRouter()


# ==========================================
# REGISTER
# ==========================================

@router.post("/register")
def register(data: RegisterRequest):

    # Check whether username already exists
    if data.username in users:
        raise HTTPException(
            status_code=400,
            detail="Username already exists"
        )

    # Check whether email already exists
    for user in users.values():

        if user["email"] == data.email:
            raise HTTPException(
                status_code=400,
                detail="Email already registered"
            )

    # Save user
    users[data.username] = {
        "username": data.username,
        "email": data.email,
        "password": hash_password(data.password)
    }

    return {
        "message": "User registered successfully",
        "username": data.username
    }


# ==========================================
# LOGIN
# ==========================================

@router.post("/login")
def login(data: LoginRequest):

    user = users.get(data.username)

    if not user:
        raise HTTPException(
            status_code=401,
            detail="Invalid username or password"
        )

    if not verify_password(
        data.password,
        user["password"]
    ):
        raise HTTPException(
            status_code=401,
            detail="Invalid username or password"
        )

    access_token = create_access_token(
        data.username
    )

    sessions[data.username] = {
        "username": data.username,
        "token": access_token,
        "logged_in": True
    }

    return {
        "message": "Login successful",
        "access_token": access_token,
        "token_type": "bearer"
    }


# ==========================================
# TOKEN
# ==========================================

@router.post("/token")
def token(data: LoginRequest):

    user = users.get(data.username)

    if not user:
        raise HTTPException(
            status_code=401,
            detail="Invalid username or password"
        )

    if not verify_password(
        data.password,
        user["password"]
    ):
        raise HTTPException(
            status_code=401,
            detail="Invalid username or password"
        )

    access_token = create_access_token(
        data.username
    )

    return {
        "access_token": access_token,
        "token_type": "bearer"
    }


# ==========================================
# LOGOUT
# ==========================================

@router.post("/logout")
def logout(username: str):

    if username not in sessions:
        return {
            "message": "User is already logged out"
        }

    sessions[username]["logged_in"] = False

    return {
        "message": "Logout successful"
    }