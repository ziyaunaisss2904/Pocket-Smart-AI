from typing import Optional

from fastapi import APIRouter, File, Form, UploadFile

from backend.models import HomeRequest, PartyRequest


router = APIRouter()


# ==========================================
# HOME PLANNER
# ==========================================

@router.post("/generate-home")
def generate_home(data: HomeRequest):

    suggestions = [
        {
            "name": "Modern Sofa",
            "category": "Furniture",
            "estimated_price": min(
                data.budget * 0.35,
                25000
            ),
            "reason": (
                f"Suitable for a {data.style} "
                f"{data.room_type}."
            )
        },
        {
            "name": "Decorative Lighting",
            "category": "Lighting",
            "estimated_price": min(
                data.budget * 0.10,
                8000
            ),
            "reason": (
                "Adds suitable lighting "
                "to the room."
            )
        },
        {
            "name": "Wall Decoration",
            "category": "Decoration",
            "estimated_price": min(
                data.budget * 0.10,
                5000
            ),
            "reason": (
                "Complements the selected "
                "interior style."
            )
        }
    ]

    return {
        "planner": "home",
        "input": data.model_dump(),
        "suggestions": suggestions
    }


# ==========================================
# PARTY PLANNER
# ==========================================

@router.post("/generate-party")
def generate_party(data: PartyRequest):

    venue = [
        f"Community hall for {data.guest_count} guests",
        "Banquet hall",
        "Outdoor event space"
    ]

    food = [
        "Welcome drinks",
        "Main course buffet",
        "Dessert section"
    ]

    decoration = [
        f"{data.decoration_style or 'Elegant'} theme decoration",
        "Balloon decoration",
        "LED lighting"
    ]

    return {
        "planner": "party",
        "input": data.model_dump(),
        "venue": venue,
        "food": food,
        "decoration": decoration
    }


# ==========================================
# JEWELRY PLANNER
# ==========================================

@router.post("/generate-jewelry")
async def generate_jewelry(
    outfit: str = Form(...),
    occasion: str = Form(...),
    budget: Optional[float] = Form(None),
    jewelry_preference: Optional[str] = Form(None),
    image: Optional[UploadFile] = File(None)
):

    image_name = None

    if image:
        image_name = image.filename

    suggestions = [
        f"Necklace suitable for {outfit} outfit.",
        f"Earrings suitable for a {occasion} occasion.",
        "Bracelet or bangles that complement the outfit."
    ]

    if jewelry_preference:
        suggestions.append(
            f"Preference: {jewelry_preference}"
        )

    return {
        "planner": "jewelry",
        "outfit": outfit,
        "occasion": occasion,
        "budget": budget,
        "image_received": image_name,
        "suggestions": suggestions
    }