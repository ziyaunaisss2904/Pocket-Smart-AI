from fastapi import APIRouter, Depends

from backend.models import RecommendationRequest
from backend.session_store import recommendation_history
from backend.routes.session_routes import get_current_user


router = APIRouter()


# ==========================================
# DETAILED RECOMMENDATIONS
# ==========================================

@router.post("/recommendations-details")
def recommendations_details(
    data: RecommendationRequest,
    username: str = Depends(get_current_user)
):

    category = data.category.lower()

    # ==========================================
    # HOME RECOMMENDATIONS
    # ==========================================

    if category == "home":

        recommendations = [
            {
                "product": "Modern Sofa",
                "category": "Furniture",
                "estimated_price": data.budget * 0.35,
                "reason": (
                    f"Suitable for your preferences: "
                    f"{data.preferences}"
                )
            },
            {
                "product": "Decorative Lighting",
                "category": "Lighting",
                "estimated_price": data.budget * 0.10,
                "reason": (
                    "Improves the room atmosphere "
                    "and overall appearance."
                )
            },
            {
                "product": "Wall Decoration",
                "category": "Decoration",
                "estimated_price": data.budget * 0.10,
                "reason": (
                    "Complements the selected "
                    "home style."
                )
            }
        ]

    # ==========================================
    # PARTY RECOMMENDATIONS
    # ==========================================

    elif category == "party":

        recommendations = [
            {
                "product": "Party Venue",
                "category": "Venue",
                "estimated_price": data.budget * 0.40,
                "reason": (
                    "Suitable for the planned "
                    "celebration."
                )
            },
            {
                "product": "Buffet Catering",
                "category": "Food",
                "estimated_price": data.budget * 0.30,
                "reason": (
                    "Provides food options "
                    "within the planned budget."
                )
            },
            {
                "product": "Theme Decoration",
                "category": "Decoration",
                "estimated_price": data.budget * 0.15,
                "reason": (
                    f"Matches your preference: "
                    f"{data.preferences}"
                )
            }
        ]

    # ==========================================
    # JEWELRY RECOMMENDATIONS
    # ==========================================

    elif category == "jewelry":

        recommendations = [
            {
                "product": "Elegant Necklace",
                "category": "Necklace",
                "estimated_price": data.budget * 0.35
                 }
        ]