from typing import Optional
from pydantic import BaseModel, Field


# ==========================================
# USER AUTHENTICATION
# ==========================================

class RegisterRequest(BaseModel):
    username: str
    email: str
    password: str


class LoginRequest(BaseModel):
    username: str
    password: str


# ==========================================
# HOME PLANNER
# ==========================================

class HomeRequest(BaseModel):
    room_type: str
    style: str
    budget: float = Field(gt=0)
    preferences: Optional[str] = None


# ==========================================
# PARTY PLANNER
# ==========================================

class PartyRequest(BaseModel):
    party_type: str
    guest_count: int = Field(gt=0)
    budget: float = Field(gt=0)
    location: Optional[str] = None
    food_preference: Optional[str] = None
    decoration_style: Optional[str] = None
    # ==========================================
# DETAILED RECOMMENDATIONS
# ==========================================

class RecommendationRequest(BaseModel):
    budget: float = Field(gt=0)
    preferences: str
    category: str
