import os
from dotenv import load_dotenv
from google import genai
from google.genai import types

# Load environment variables
load_dotenv()

# Get API key
api_key = os.getenv("GEMINI_API_KEY")

if not api_key:
    raise ValueError("GEMINI_API_KEY is not set in the .env file")

# Create Gemini client
client = genai.Client(api_key=api_key)

# Load image
with open("test_image.jpg", "rb") as f:
    image_bytes = f.read()

# Send image + text prompt
response = client.models.generate_content(
    model="gemini-3.8-flash",
    contents=[
        types.Part.from_bytes(
            data=image_bytes,
            mime_type="image/jpg"
        ),
        "Describe this image and identify the main objects you can see."
    ]
)

print("=" * 50)
print("Gemini Multimodal Test Successful!")
print("=" * 50)
print()
print(response.text)